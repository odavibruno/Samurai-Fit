
import React, { useState, useEffect } from 'react';
import Layout from './components/Layout';
import Dashboard from './components/Dashboard';
import WorkoutsView from './components/WorkoutsView';
import BattleTechniques from './components/BattleTechniques';
import AICoach from './components/AICoach';
import HealthView from './components/HealthView';
import StudentManager from './components/StudentManager';
import InstructorSchedule from './components/InstructorSchedule';
import MasterTrackingLog from './components/MasterTrackingLog';
import Login from './components/Login';
import OnboardingFlow from './components/OnboardingFlow';
import QuestionnaireModal from './components/QuestionnaireModal'; // Novo Import
import { analyzeStudentProfile } from './services/geminiService'; // Novo Import
import { NavigationTab, UserProfile, UserStats, Message, Student, SoundConfig, ActiveWorkoutSession, Workout, AudioSettings } from './types';
import { INITIAL_USER_DATA, SAGE_AVATAR } from './constants';
import { Save, X, Camera, ChevronDown, ChevronUp, Info, Lock, Send, Key, Users, CheckSquare, Square, ShieldAlert, CreditCard, User, AlertCircle, CheckCircle2, History, ArrowUpRight, Clock, Play, ScrollText, Shield } from 'lucide-react';

const DEFAULT_SOUND_CONFIG: SoundConfig = {
  start: ['', '', ''],
  rest: ['', '', ''],
  finish: ['', '', ''],
  selectedStart: 0,
  selectedRest: 0,
  selectedFinish: 0
};

const DEFAULT_AUDIO_SETTINGS: AudioSettings = {
  masterEnabled: true,
  masterVolume: 1.0,
  types: {
    start: { enabled: true, volume: 1.0 },
    rest: { enabled: true, volume: 1.0 },
    finish: { enabled: true, volume: 1.0 },
    ui: { enabled: true, volume: 0.5 } // Sons de clique e interação
  }
};

const App: React.FC = () => {
  // Verifica autenticação no localStorage
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    return localStorage.getItem('samurai_auth') === 'true';
  });
  
  const [activeTab, setActiveTab] = useState<NavigationTab>(NavigationTab.DOJO);
  
  const [theme, setTheme] = useState<'Dia' | 'Noite'>(() => {
    return (localStorage.getItem('samurai_theme') as 'Dia' | 'Noite') || 'Noite';
  });

  // --- AUDIO SETTINGS (SUBSTITUI O BOOLEAN SOUNDS) ---
  const [audioSettings, setAudioSettings] = useState<AudioSettings>(() => {
    const saved = localStorage.getItem('samurai_audio_settings');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        // Merge para garantir que novas propriedades existam se a estrutura mudar
        return { ...DEFAULT_AUDIO_SETTINGS, ...parsed, types: { ...DEFAULT_AUDIO_SETTINGS.types, ...parsed.types } };
      } catch (e) {
        return DEFAULT_AUDIO_SETTINGS;
      }
    }
    // Fallback para migração do sistema antigo (se existia 'samurai_sounds' boolean)
    const oldSoundBoolean = localStorage.getItem('samurai_sounds');
    if (oldSoundBoolean !== null) {
        const isEnabled = JSON.parse(oldSoundBoolean);
        return { ...DEFAULT_AUDIO_SETTINGS, masterEnabled: isEnabled };
    }
    return DEFAULT_AUDIO_SETTINGS;
  });

  useEffect(() => {
    localStorage.setItem('samurai_audio_settings', JSON.stringify(audioSettings));
  }, [audioSettings]);
  
  // Estado do Avatar do Sábio (Persistente)
  const [sageAvatar, setSageAvatar] = useState<string>(() => {
    return localStorage.getItem('sage_avatar') || SAGE_AVATAR;
  });

  // Estado dos Ícones Personalizados (Persistente)
  const [customIcons, setCustomIcons] = useState<Record<string, string>>(() => {
    const saved = localStorage.getItem('samurai_custom_icons');
    return saved ? JSON.parse(saved) : {};
  });

  // Estado de Configuração de Sons (Persistente)
  const [soundConfig, setSoundConfig] = useState<SoundConfig>(() => {
    const saved = localStorage.getItem('samurai_sound_config');
    return saved ? JSON.parse(saved) : DEFAULT_SOUND_CONFIG;
  });

  // --- SESSÃO ATIVA DE TREINO (PERSISTENTE) ---
  const [activeSession, setActiveSession] = useState<ActiveWorkoutSession | null>(() => {
    const savedSession = localStorage.getItem('samurai_active_session');
    return savedSession ? JSON.parse(savedSession) : null;
  });

  // Salva sessão sempre que mudar
  useEffect(() => {
    if (activeSession) {
      localStorage.setItem('samurai_active_session', JSON.stringify(activeSession));
    } else {
      localStorage.removeItem('samurai_active_session');
    }
  }, [activeSession]);

  // Alerta ao abrir se houver treino incompleto
  useEffect(() => {
    if (isAuthenticated && activeSession) {
       // Pequeno delay para garantir renderização
       setTimeout(() => {
           alert("⚠️ ATENÇÃO GUERREIRO!\n\nVocê tem uma batalha incompleta.\nComplete seu treino agora para manter a honra.");
       }, 500);
    }
  }, [isAuthenticated]); // Roda apenas na autenticação inicial

  // --- FUNÇÕES DE CONTROLE DE TREINO ---

  const handleStartSession = (workout: Workout) => {
    const newSession: ActiveWorkoutSession = {
      workoutId: workout.id,
      workoutTitle: workout.title,
      startTime: new Date().toISOString(),
      lastResumeTime: new Date().toISOString(),
      accumulatedDuration: 0,
      isPaused: false,
      currentExerciseIndex: 0,
      sessionData: {}
    };
    setActiveSession(newSession);
  };

  const handlePauseSession = () => {
    if (!activeSession || activeSession.isPaused) return;
    
    const now = new Date();
    const lastResume = activeSession.lastResumeTime ? new Date(activeSession.lastResumeTime) : now;
    const additionalTime = (now.getTime() - lastResume.getTime()) / 1000; // Segundos

    setActiveSession({
      ...activeSession,
      isPaused: true,
      lastResumeTime: null,
      accumulatedDuration: activeSession.accumulatedDuration + additionalTime
    });
  };

  const handleResumeSession = () => {
    if (!activeSession || !activeSession.isPaused) return;

    setActiveSession({
      ...activeSession,
      isPaused: false,
      lastResumeTime: new Date().toISOString()
    });
  };

  const handleUpdateSessionData = (exerciseId: string, setIndex: number, data: { weight: number, reps: string, done: boolean }) => {
    if (!activeSession) return;
    
    const newSessionData = { ...activeSession.sessionData };
    if (!newSessionData[exerciseId]) newSessionData[exerciseId] = {};
    newSessionData[exerciseId][setIndex] = data;

    setActiveSession({
      ...activeSession,
      sessionData: newSessionData
    });
  };

  const handleFinishSession = () => {
    setActiveSession(null);
  };

  const handleUpdateSoundConfig = (newConfig: SoundConfig) => {
    setSoundConfig(newConfig);
    localStorage.setItem('samurai_sound_config', JSON.stringify(newConfig));
  };

  const handleUpdateSageAvatar = (newUrl: string) => {
    setSageAvatar(newUrl);
    localStorage.setItem('sage_avatar', newUrl);
  };

  const handleUpdateIcon = (tabId: string, newUrl: string) => {
    const updated = { ...customIcons, [tabId]: newUrl };
    setCustomIcons(updated);
    localStorage.setItem('samurai_custom_icons', JSON.stringify(updated));
  };

  const handleResetIcon = (tabId: string) => {
    const updated = { ...customIcons };
    delete updated[tabId];
    setCustomIcons(updated);
    localStorage.setItem('samurai_custom_icons', JSON.stringify(updated));
  };
  
  // Lógica de Inicialização com Migração de Dados
  const [user, setUser] = useState<UserProfile>(() => {
    const savedUser = localStorage.getItem('samurai_user');
    let baseData = savedUser ? JSON.parse(savedUser) : INITIAL_USER_DATA;
    
    // --- MIGRAÇÃO DE DADOS PARA PREVENIR ERROS ---
    if (!baseData.trainingLogs) baseData.trainingLogs = INITIAL_USER_DATA.trainingLogs;
    if (baseData.goals && baseData.goals.length > 0) {
        if (typeof baseData.goals[0].target === 'string') {
             baseData.goals = INITIAL_USER_DATA.goals;
        }
    } else {
        baseData.goals = INITIAL_USER_DATA.goals;
    }
    if (!baseData.statsHistory) baseData.statsHistory = INITIAL_USER_DATA.statsHistory;
    if (!baseData.dailyMeals) baseData.dailyMeals = INITIAL_USER_DATA.dailyMeals;
    if (!baseData.financial) {
        baseData.financial = { status: 'Em dia', plan: 'Mensal', dueDate: new Date().toISOString().split('T')[0], lastPayment: new Date().toISOString().split('T')[0], value: 120, history: [] };
    }
    if (baseData.financial && !baseData.financial.history) {
        baseData.financial.history = INITIAL_USER_DATA.financial?.history || [];
    }
    if (!baseData.schedule) baseData.schedule = [];

    // Garantir flags de controle de acesso se não existirem
    if (baseData.isFirstLogin === undefined) baseData.isFirstLogin = false;
    if (baseData.hasAcceptedTerms === undefined) baseData.hasAcceptedTerms = true;

    if (!baseData.messages) {
      baseData.messages = [
        { id: '1', senderName: 'Mestre Samurai', title: 'Novo Protocolo', content: 'O mestre atualizou sua ficha de guerra. Foco na execução dos movimentos compostos.', date: 'Hoje', isRead: false },
        { id: '2', senderName: 'Mestre Samurai', title: 'Mensagem do Clã', content: 'Treino coletivo no próximo sábado às 08h. Presença obrigatória para os que buscam a ascensão.', date: 'Ontem', isRead: true }
      ];
    }
    return baseData;
  });
  
  // Lista de membros do Clã (Persistido no localStorage para simular DB)
  // Limpo para produção (apenas o Mestre inicializado)
  const [clanMembers, setClanMembers] = useState<Student[]>(() => {
    const savedMembers = localStorage.getItem('samurai_clan_members');
    if (savedMembers) return JSON.parse(savedMembers);

    return [
      { 
        id: 'master-01', 
        name: 'Warllley Samurai', 
        email: 'w.samurai.fitness@gmail.com', 
        goal: 'Liderança Suprema', 
        level: 'Xogum (Mestre)', 
        birthDate: '1990-01-01', 
        gender: 'Masculino', 
        weight: 88, 
        height: 182, 
        waterIntake: 4.0, 
        date: '2024-01-01', 
        phone: '(11) 99999-9999',
        isLider: true, 
        workouts: [],
        password: 'admin' // Senha padrão mestre
      }
    ];
  });

  // Salvar clanMembers sempre que mudar (para persistir novos alunos criados)
  useEffect(() => {
    localStorage.setItem('samurai_clan_members', JSON.stringify(clanMembers));
  }, [clanMembers]);

  const [isEditingProfile, setIsEditingProfile] = useState<boolean>(false);
  const [editingUser, setEditingUser] = useState<UserProfile | null>(null); 
  const [profileTab, setProfileTab] = useState<'PERSONAL' | 'FINANCIAL'>('PERSONAL');

  const [isManagingStudents, setIsManagingStudents] = useState<boolean>(false);
  const [isMessagingClan, setIsMessagingClan] = useState<boolean>(false);
  const [isScheduleOpen, setIsScheduleOpen] = useState<boolean>(false);
  const [scheduleTargetStudentId, setScheduleTargetStudentId] = useState<string | null>(null);
  
  // Novo Estado para o Pergaminho do Mestre e Questionário
  const [isMasterTrackingOpen, setIsMasterTrackingOpen] = useState<boolean>(false);
  const [isQuestionnaireOpen, setIsQuestionnaireOpen] = useState<boolean>(false);

  const [showAdvancedEdit, setShowAdvancedEdit] = useState<boolean>(false);
  const [showPasswordEdit, setShowPasswordEdit] = useState<boolean>(false);
  const [isContactingMaster, setIsContactingMaster] = useState<boolean>(false);
  const [masterMessage, setMasterMessage] = useState('');
  
  const [nextClassAlert, setNextClassAlert] = useState<{ studentName: string, time: string } | null>(null);

  const [broadcastTitle, setBroadcastTitle] = useState('');
  const [broadcastContent, setBroadcastContent] = useState('');
  const [selectedRecipients, setSelectedRecipients] = useState<string[]>([]);

  const [currentPass, setCurrentPass] = useState('');
  const [newPass, setNewPass] = useState('');
  const [confirmNewPass, setConfirmNewPass] = useState('');

  useEffect(() => {
    localStorage.setItem('samurai_theme', theme);
  }, [theme]);

  useEffect(() => {
    if (isAuthenticated) {
      localStorage.setItem('samurai_user', JSON.stringify(user));
    }
  }, [user, isAuthenticated]);

  // Efeito para verificar aulas próximas a cada minuto
  useEffect(() => {
    if (!isAuthenticated || !user.schedule) return;

    const checkNextClass = () => {
        const now = new Date();
        const currentDateStr = now.toISOString().split('T')[0];
        const currentTimeMinutes = now.getHours() * 60 + now.getMinutes();

        const upcomingClass = user.schedule.find(s => {
            if (s.date !== currentDateStr) return false;
            const [h, m] = s.time.split(':').map(Number);
            const classTimeMinutes = h * 60 + m;
            const diff = classTimeMinutes - currentTimeMinutes;
            return diff >= 0 && diff <= 20; 
        });

        if (upcomingClass) {
            setNextClassAlert({ studentName: upcomingClass.studentName, time: upcomingClass.time });
        } else {
            setNextClassAlert(null); 
        }
    };

    const interval = setInterval(checkNextClass, 60000); 
    checkNextClass(); 

    return () => clearInterval(interval);
  }, [user.schedule, isAuthenticated]);

  const handleTabChange = (tab: NavigationTab) => {
    setActiveTab(tab);
    setIsEditingProfile(false);
    setEditingUser(null);
    setIsManagingStudents(false);
    setIsMessagingClan(false);
    setIsContactingMaster(false);
    setIsScheduleOpen(false);
    setIsMasterTrackingOpen(false);
    setIsQuestionnaireOpen(false); // Fecha questionário
    setScheduleTargetStudentId(null);
    setMasterMessage('');
    setBroadcastTitle('');
    setBroadcastContent('');
    setSelectedRecipients([]);
  };

  const handleStartEditProfile = () => {
    setEditingUser(JSON.parse(JSON.stringify(user)));
    setProfileTab('PERSONAL'); 
    setIsEditingProfile(true);
  };

  const handleOpenScheduleForStudent = (studentId?: string) => {
      setScheduleTargetStudentId(studentId || null);
      setIsScheduleOpen(true);
      setIsManagingStudents(false); 
  };

  // --- LÓGICA DE SALVAMENTO DO QUESTIONÁRIO E IA ---
  const handleSaveQuestionnaire = async (answers: { question: string; answer: string }[]) => {
    setIsQuestionnaireOpen(false);
    alert("Respostas enviadas ao Mestre! A IA está analisando seu perfil estratégico...");

    // 1. Atualizar o usuário atual localmente com as respostas cruas
    const updatedUser = { 
        ...user, 
        questionnaire: { answeredAt: new Date().toISOString(), answers, aiSummary: "Analisando..." } 
    };
    setUser(updatedUser);

    // 2. Chamar a IA para gerar o resumo
    try {
        const aiSummary = await analyzeStudentProfile(answers, user.name);
        
        // 3. Atualizar o usuário e a lista do Clã com o resumo final
        const finalUser = {
            ...updatedUser,
            questionnaire: { ...updatedUser.questionnaire!, aiSummary }
        };
        setUser(finalUser);

        // Atualiza na lista global de membros
        const updatedClan = clanMembers.map(m => m.id === finalUser.id ? finalUser : m);
        setClanMembers(updatedClan);
        
        alert("Análise estratégica concluída e salva no pergaminho do Mestre.");

    } catch (error) {
        console.error("Erro na análise IA:", error);
    }
  };

  const handleLogin = async (email: string, passwordInput: string): Promise<boolean> => {
    // 1. Verifica se é o Mestre (Hardcoded por segurança ou via lista)
    const masterEmails = ['w.samurai.fitness@gmail.com'];
    const isMasterEmail = masterEmails.includes(email.toLowerCase());

    // 2. Busca o usuário na lista de membros do Clã
    const registeredMember = clanMembers.find(m => m.email.toLowerCase() === email.toLowerCase());

    if (!registeredMember) {
        // Se não encontrar o e-mail na lista de alunos do mestre, nega acesso
        // A MENOS que seja o email mestre hardcoded e não esteja na lista (fallback)
        if (!isMasterEmail) return false; 
    }

    // 3. Validação de Senha
    // Se for mestre hardcoded, senha fixa para recuperação se necessário, ou a do objeto
    if (isMasterEmail && passwordInput === '123456') {
        // Login Mestre Sucedido
    } else if (registeredMember) {
        // Verifica a senha do aluno
        // Se o aluno não tiver senha definida (ex: migração), aceita '123456' ou falha
        const storedPass = registeredMember.password || '123456'; 
        if (storedPass !== passwordInput) {
            return false; // Senha incorreta
        }
    } else {
        return false; // Caso residual
    }

    // 4. Configurar Sessão
    setIsAuthenticated(true);
    localStorage.setItem('samurai_auth', 'true');
    localStorage.setItem('user_email', email);
    
    // Constrói o perfil do usuário logado baseando-se no registro do clã
    const memberData = registeredMember || INITIAL_USER_DATA;
    
    let updatedUser: UserProfile = { 
      ...user, // Mantém dados locais existentes como histórico de mensagens/treinos locais se houver
      ...memberData, // Sobrescreve com dados do servidor (mock)
      email,
      isLider: isMasterEmail ? true : (memberData.isLider || false),
      level: isMasterEmail ? 'Xogum (Mestre)' : memberData.level,
      // Garante arrays e objetos novos
      workouts: memberData.workouts || [],
      trainingLogs: memberData.trainingLogs || [],
      schedule: user.schedule || [],
      questionnaire: memberData.questionnaire 
    };

    if (isMasterEmail) {
        updatedUser.name = 'Warllley Samurai';
        updatedUser.isLider = true;
        updatedUser.isFirstLogin = false; 
        updatedUser.hasAcceptedTerms = true;
    }

    setUser(updatedUser);
    return true;
  };

  const handleLogout = () => {
    localStorage.removeItem('samurai_auth');
    localStorage.removeItem('user_email');
    localStorage.removeItem('samurai_user');
    setIsAuthenticated(false);
    setUser(INITIAL_USER_DATA);
    handleTabChange(NavigationTab.DOJO);
  };

  const handleOnboardingComplete = (newPassword: string) => {
      const updatedUser = {
          ...user,
          password: newPassword,
          isFirstLogin: false,
          hasAcceptedTerms: true
      };
      setUser(updatedUser);
      localStorage.setItem('samurai_user', JSON.stringify(updatedUser));
      
      // Atualiza também na lista do clã para persistir a nova senha
      const updatedClan = clanMembers.map(m => m.email === user.email ? { ...m, password: newPassword, isFirstLogin: false, hasAcceptedTerms: true } : m);
      setClanMembers(updatedClan);
      
      alert("Bem-vindo ao Dojo, Guerreiro! Seu acesso está liberado.");
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        if (isEditingProfile && editingUser) {
           setEditingUser({ ...editingUser, profileImage: reader.result as string });
        } else {
           setUser({ ...user, profileImage: reader.result as string });
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const formatBRPhone = (value: string) => {
    if (!value) return "";
    value = value.replace(/\D/g, "");
    if (value.length > 11) value = value.slice(0, 11);
    
    if (value.length > 10) {
      return value.replace(/(\d{2})(\d{5})(\d{4})/, "($1) $2-$3");
    } else if (value.length > 6) {
      return value.replace(/(\d{2})(\d{4})(\d{0,4})/, "($1) $2-$3");
    } else if (value.length > 2) {
      return value.replace(/(\d{2})(\d{0,5})/, "($1) $2");
    } else {
      return value;
    }
  };

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingUser) return;

    if (showPasswordEdit && newPass) {
      if (currentPass !== user.password) {
        alert("Código atual incorreto.");
        return;
      }
      if (newPass !== confirmNewPass) {
        alert("Os novos códigos não coincidem.");
        return;
      }
      editingUser.password = newPass; 
      alert("Código de acesso atualizado com sucesso.");
    }
    
    setUser(editingUser);
    
    // Atualiza na lista de membros também
    const updatedClan = clanMembers.map(m => m.id === editingUser.id ? editingUser : m);
    setClanMembers(updatedClan);
    
    setIsEditingProfile(false);
    setEditingUser(null);
    setShowAdvancedEdit(false);
    setShowPasswordEdit(false);
    setCurrentPass('');
    setNewPass('');
    setConfirmNewPass('');
  };

  const isMestre = !!(user.isLider || ['w.samurai.fitness@gmail.com'].includes(user.email.toLowerCase()));

  const deleteMessage = (id: string) => {
    setUser({ ...user, messages: user.messages.filter(m => m.id !== id) });
  };

  const handleSendMessageToMaster = () => {
    if (!masterMessage.trim()) return;
    alert("Mensagem enviada ao pergaminho do Mestre.");
    setMasterMessage('');
    setIsContactingMaster(false);
  };

  const toggleRecipient = (id: string) => {
    setSelectedRecipients(prev => 
      prev.includes(id) ? prev.filter(r => r !== id) : [...prev, id]
    );
  };

  const toggleAllRecipients = () => {
    if (selectedRecipients.length === clanMembers.length) {
      setSelectedRecipients([]);
    } else {
      setSelectedRecipients(clanMembers.map(m => m.id));
    }
  };

  const handleBroadcastMessage = () => {
    if (!broadcastTitle.trim() || !broadcastContent.trim() || selectedRecipients.length === 0) {
      alert("Preencha todos os campos e selecione pelo menos um membro.");
      return;
    }
    alert(`Mensagem "${broadcastTitle}" disparada para ${selectedRecipients.length} membros do clã.`);
    setBroadcastTitle('');
    setBroadcastContent('');
    setSelectedRecipients([]);
    setIsMessagingClan(false);
  };

  const handleUpdateStudentFromManager = (updatedStudent: Student) => {
    if (updatedStudent.id === user.id || updatedStudent.email.toLowerCase() === user.email.toLowerCase()) {
      setUser(prev => ({ ...prev, ...updatedStudent }));
    }
    
    setClanMembers(prev => {
      if (prev.some(m => m.id === updatedStudent.id)) {
        return prev.map(m => m.id === updatedStudent.id ? updatedStudent : m);
      } else {
        return [...prev, updatedStudent];
      }
    });
  };

  const handleDeleteStudent = (id: string) => {
    if (window.confirm("Tem certeza que deseja expulsar este membro do clã?")) {
      setClanMembers(prev => prev.filter(m => m.id !== id));
    }
  };

  const renderContent = () => {
    if (isEditingProfile && editingUser) {
      const inputBg = theme === 'Noite' ? 'bg-black/40 border-white/10' : 'bg-slate-50 border-zinc-200';
      const textColor = theme === 'Noite' ? 'text-white' : 'text-zinc-900';

      return (
        <div className="space-y-6 animate-in fade-in zoom-in-95 duration-300 pb-20">
          <div className="flex justify-between items-center mb-4">
            <h2 className={`text-2xl font-black italic uppercase ${theme === 'Dia' ? 'text-zinc-900' : 'text-white'}`}>Meu Perfil</h2>
            <button onClick={() => { setIsEditingProfile(false); setEditingUser(null); setShowAdvancedEdit(false); setShowPasswordEdit(false); }} className="p-2 text-zinc-500 hover:text-red-900 transition-colors"><X size={28} /></button>
          </div>
          
           <div className={`flex p-1 rounded-2xl mb-6 ${theme === 'Noite' ? 'bg-zinc-800' : 'bg-zinc-200'}`}>
             <button 
                onClick={() => setProfileTab('PERSONAL')}
                className={`flex-1 py-3 rounded-xl text-xs font-black uppercase tracking-widest flex items-center justify-center gap-2 transition-all ${
                    profileTab === 'PERSONAL' 
                    ? (theme === 'Noite' ? 'bg-zinc-700 text-white shadow-md' : 'bg-white text-red-900 shadow-md') 
                    : (theme === 'Noite' ? 'text-zinc-400 hover:text-white' : 'text-zinc-600 hover:text-red-900')
                }`}
             >
                <User size={14} /> Dados
             </button>
             <button 
                onClick={() => setProfileTab('FINANCIAL')}
                className={`flex-1 py-3 rounded-xl text-xs font-black uppercase tracking-widest flex items-center justify-center gap-2 transition-all ${
                    profileTab === 'FINANCIAL' 
                    ? (theme === 'Noite' ? 'bg-zinc-700 text-white shadow-md' : 'bg-white text-red-900 shadow-md') 
                    : (theme === 'Noite' ? 'text-zinc-400 hover:text-white' : 'text-zinc-600 hover:text-red-900')
                }`}
             >
                <CreditCard size={14} /> Financeiro
             </button>
          </div>

          {profileTab === 'PERSONAL' ? (
             <form onSubmit={handleSaveProfile} className="space-y-6 animate-in slide-in-from-left-4">
                
                {/* Foto */}
                <div className="flex justify-center mb-6">
                  <div className="relative group">
                    <div className="w-24 h-24 rounded-full bg-zinc-800 overflow-hidden border-2 border-red-900">
                      {editingUser.profileImage ? (
                        <img src={editingUser.profileImage} alt="Perfil" className="w-full h-full object-cover" />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center text-zinc-500 font-black text-2xl">
                          {editingUser.name.charAt(0)}
                        </div>
                      )}
                    </div>
                    <label className="absolute bottom-0 right-0 p-2 bg-red-900 rounded-full text-white cursor-pointer shadow-lg hover:bg-red-800 transition-colors">
                      <Camera size={14} />
                      <input type="file" className="hidden" accept="image/*" onChange={handleFileChange} />
                    </label>
                  </div>
                </div>

                {/* VISUALIZAÇÃO DO NÍVEL (SOMENTE LEITURA) */}
                <div className={`p-5 rounded-2xl border ${theme === 'Noite' ? 'bg-red-900/10 border-red-900/30' : 'bg-red-50 border-red-100'} flex items-center justify-between`}>
                    <div>
                        <p className="text-[10px] font-black uppercase text-zinc-500 tracking-widest mb-1 flex items-center gap-1">
                            <Shield size={12} className="text-red-900" /> Nível Atual
                        </p>
                        <h3 className="text-xl font-black uppercase text-red-900 italic">{editingUser.level}</h3>
                    </div>
                    <div className="text-[9px] font-bold uppercase text-zinc-500 text-right opacity-60">
                        <Lock size={12} className="inline mb-1"/>
                        <br/>
                        Definido pelo Mestre
                    </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-[10px] font-black uppercase text-zinc-500 ml-1">Nome</label>
                    <input className={`w-full ${inputBg} p-4 rounded-2xl text-sm font-bold ${textColor}`} value={editingUser.name} onChange={e => setEditingUser({...editingUser, name: e.target.value})} required />
                  </div>
                  
                  {/* EMAIL - SOMENTE LEITURA */}
                  <div className="space-y-1 opacity-75">
                    <label className="text-[10px] font-black uppercase text-zinc-500 ml-1 flex items-center gap-2">Email <Lock size={10}/></label>
                    <input 
                        type="email" 
                        disabled
                        className={`w-full ${inputBg} p-4 rounded-2xl text-sm font-bold ${textColor} cursor-not-allowed border-dashed border-zinc-600`} 
                        value={editingUser.email} 
                    />
                  </div>

                   <div className="space-y-1">
                    <label className="text-[10px] font-black uppercase text-zinc-500 ml-1">Telefone</label>
                    <input className={`w-full ${inputBg} p-4 rounded-2xl text-sm font-bold ${textColor}`} value={editingUser.phone || ''} onChange={e => setEditingUser({...editingUser, phone: formatBRPhone(e.target.value)})} />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] font-black uppercase text-zinc-500 ml-1">Nascimento</label>
                    <input type="date" className={`w-full ${inputBg} p-4 rounded-2xl text-sm font-bold ${textColor}`} value={editingUser.birthDate} onChange={e => setEditingUser({...editingUser, birthDate: e.target.value})} />
                  </div>
                </div>

                {/* BIOGRAFIA (EDITÁVEL PELO ALUNO) */}
                <div className="space-y-1">
                    <label className="text-[10px] font-black uppercase text-zinc-500 ml-1 flex items-center gap-2">
                        <ScrollText size={12}/> Minha Biografia (História)
                    </label>
                    <textarea 
                        className={`w-full h-32 ${inputBg} p-4 rounded-2xl text-sm font-bold ${textColor} resize-none focus:outline-none focus:border-red-900 transition-all`}
                        placeholder="Escreva sua história, lesões passadas ou motivações..."
                        value={editingUser.biography || ''}
                        onChange={e => setEditingUser({...editingUser, biography: e.target.value})}
                    />
                </div>

                <div className="grid grid-cols-2 gap-4">
                   <div className="space-y-1">
                     <label className="text-[10px] font-black uppercase text-zinc-500 ml-1">Peso (kg)</label>
                     <input type="number" className={`w-full ${inputBg} p-4 rounded-2xl text-sm font-bold ${textColor}`} value={editingUser.weight} onChange={e => setEditingUser({...editingUser, weight: Number(e.target.value)})} />
                   </div>
                   <div className="space-y-1">
                     <label className="text-[10px] font-black uppercase text-zinc-500 ml-1">Altura (cm)</label>
                     <input type="number" className={`w-full ${inputBg} p-4 rounded-2xl text-sm font-bold ${textColor}`} value={editingUser.height} onChange={e => setEditingUser({...editingUser, height: Number(e.target.value)})} />
                   </div>
                </div>

                <div className={`p-4 rounded-2xl border ${theme === 'Noite' ? 'border-zinc-800 bg-zinc-900/50' : 'border-zinc-200 bg-zinc-50'}`}>
                    <button 
                      type="button" 
                      onClick={() => setShowPasswordEdit(!showPasswordEdit)}
                      className="flex items-center justify-between w-full text-xs font-black uppercase text-zinc-500 hover:text-red-900 transition-colors"
                    >
                      <span className="flex items-center gap-2"><Lock size={14} /> Alterar Código de Honra (Senha)</span>
                      {showPasswordEdit ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
                    </button>
                    
                    {showPasswordEdit && (
                      <div className="mt-4 space-y-3 animate-in slide-in-from-top-2">
                         <input type="password" placeholder="Senha Atual" className={`w-full ${inputBg} p-3 rounded-xl text-sm`} value={currentPass} onChange={e => setCurrentPass(e.target.value)} />
                         <input type="password" placeholder="Nova Senha" className={`w-full ${inputBg} p-3 rounded-xl text-sm`} value={newPass} onChange={e => setNewPass(e.target.value)} />
                         <input type="password" placeholder="Confirmar Nova Senha" className={`w-full ${inputBg} p-3 rounded-xl text-sm`} value={confirmNewPass} onChange={e => setConfirmNewPass(e.target.value)} />
                      </div>
                    )}
                </div>

               <button type="submit" className="w-full bg-red-900 text-white font-black py-5 rounded-3xl shadow-2xl italic uppercase tracking-widest active:scale-95 transition-all shadow-red-900/20 flex items-center justify-center gap-2">
                 <Save size={18} /> ATUALIZAR PERGAMINHO
               </button>
             </form>
          ) : (
              <div className="animate-in slide-in-from-right-4 space-y-6">
                 {editingUser.financial ? (
                    <>
                      <div className={`p-6 rounded-3xl border flex items-center justify-between ${editingUser.financial.status === 'Em dia' ? 'bg-green-900/10 border-green-900/30' : editingUser.financial.status === 'Atrasado' ? 'bg-red-900/10 border-red-900/30' : 'bg-yellow-600/10 border-yellow-600/30'}`}>
                          <div>
                            <p className="text-[10px] font-black uppercase text-zinc-500 tracking-widest">Status Atual</p>
                            <h3 className={`text-2xl font-black uppercase italic ${editingUser.financial.status === 'Em dia' ? 'text-green-600' : editingUser.financial.status === 'Atrasado' ? 'text-red-600' : 'text-yellow-600'}`}>{editingUser.financial.status}</h3>
                          </div>
                          {editingUser.financial.status === 'Atrasado' ? <AlertCircle size={32} className="text-red-600" /> : <CheckCircle2 size={32} className="text-green-600" />}
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                         <div className={`p-4 rounded-2xl ${inputBg}`}>
                            <p className="text-[9px] font-black uppercase text-zinc-500">Plano</p>
                            <p className={`text-lg font-black uppercase ${textColor}`}>{editingUser.financial.plan}</p>
                         </div>
                         <div className={`p-4 rounded-2xl ${inputBg}`}>
                            <p className="text-[9px] font-black uppercase text-zinc-500">Valor</p>
                            <p className={`text-lg font-black uppercase ${textColor}`}>R$ {editingUser.financial.value}</p>
                         </div>
                         <div className={`p-4 rounded-2xl ${inputBg}`}>
                            <p className="text-[9px] font-black uppercase text-zinc-500">Vencimento</p>
                            <p className={`text-lg font-black uppercase ${textColor}`}>{editingUser.financial.dueDate.split('-').reverse().join('/')}</p>
                         </div>
                         <div className={`p-4 rounded-2xl ${inputBg}`}>
                            <p className="text-[9px] font-black uppercase text-zinc-500">Último Pagamento</p>
                            <p className={`text-lg font-black uppercase ${textColor}`}>{editingUser.financial.lastPayment.split('-').reverse().join('/')}</p>
                         </div>
                      </div>

                      <div className="space-y-3">
                         <h4 className="text-xs font-black uppercase text-zinc-500 ml-1">Histórico de Contribuição</h4>
                         {editingUser.financial.history && editingUser.financial.history.length > 0 ? (
                           editingUser.financial.history.map((h: any, i: number) => (
                             <div key={i} className={`p-4 rounded-2xl border flex justify-between items-center ${theme === 'Noite' ? 'bg-zinc-900 border-zinc-800' : 'bg-white border-zinc-100 shadow-sm'}`}>
                                <div>
                                   <p className={`text-xs font-black ${textColor}`}>{h.date.split('-').reverse().join('/')}</p>
                                   <p className="text-[9px] font-bold text-zinc-500 uppercase">{h.method}</p>
                                </div>
                                <div className="text-right">
                                   <p className="text-xs font-black text-green-600">R$ {h.amount}</p>
                                   <p className="text-[9px] font-bold text-zinc-500 uppercase">{h.status}</p>
                                </div>
                             </div>
                           ))
                         ) : (
                           <p className="text-center text-xs text-zinc-500 italic py-4">Nenhum registro encontrado.</p>
                         )}
                      </div>
                    </>
                 ) : (
                    <div className="text-center py-10 opacity-50">
                        <CreditCard size={40} className="mx-auto mb-2 text-zinc-600" />
                        <p className="text-xs font-bold uppercase italic text-zinc-500">Dados financeiros indisponíveis</p>
                    </div>
                 )}
              </div>
          )}
        </div>
      );
    }

    switch (activeTab) {
      case NavigationTab.DOJO: return <Dashboard user={user} onUpdateUser={setUser} theme={theme} activeSession={activeSession} onResumeSession={() => setActiveTab(NavigationTab.WORKOUTS)} />;
      case NavigationTab.TECHNIQUES: return <BattleTechniques isLider={isMestre} theme={theme} />;
      case NavigationTab.WORKOUTS: 
        return (
            <WorkoutsView 
                workouts={user.workouts} 
                theme={theme} 
                soundConfig={soundConfig}
                audioSettings={audioSettings}
                onUpdateAudioSettings={setAudioSettings}
                activeSession={activeSession}
                onStartSession={handleStartSession}
                onPauseSession={handlePauseSession}
                onResumeSession={handleResumeSession}
                onUpdateSessionData={handleUpdateSessionData}
                onFinishSession={handleFinishSession}
            />
        );
      case NavigationTab.AI_COACH: return <AICoach user={user} theme={theme} sageAvatar={sageAvatar} onUpdateSageAvatar={handleUpdateSageAvatar} />;
      case NavigationTab.HEALTH: return <HealthView user={user} theme={theme} />;
      default: return <Dashboard user={user} onUpdateUser={setUser} theme={theme} activeSession={activeSession} onResumeSession={() => setActiveTab(NavigationTab.WORKOUTS)} />;
    }
  };

  return (
    <div className={`transition-colors duration-500 min-h-screen ${theme === 'Dia' ? 'bg-[#f7f9fc]' : 'bg-[#0A0A0A]'}`}>
      {isAuthenticated ? (
        <>
          {/* VERIFICAÇÃO DE FLUXO DE ONBOARDING */}
          {/* Se for primeiro login OU se não aceitou os termos, exibe o fluxo obrigatório */}
          {(user.isFirstLogin || !user.hasAcceptedTerms) ? (
              <OnboardingFlow user={user} onComplete={handleOnboardingComplete} theme={theme} />
          ) : (
            <>
                {/* Alerta de Próxima Aula */}
                {nextClassAlert && (
                    <div className="fixed top-24 left-1/2 -translate-x-1/2 z-[100] animate-in slide-in-from-top-4">
                        <div className="bg-red-900 text-white px-6 py-3 rounded-full shadow-[0_0_20px_rgba(220,38,38,0.5)] border border-red-500 flex items-center gap-3">
                            <Clock size={20} className="animate-pulse" />
                            <div>
                                <p className="text-[10px] font-black uppercase tracking-widest opacity-80">Atenção Mestre</p>
                                <p className="text-sm font-bold uppercase italic">Aula com {nextClassAlert.studentName} às {nextClassAlert.time}</p>
                            </div>
                        </div>
                    </div>
                )}
                
                <Layout 
                    activeTab={activeTab} setActiveTab={handleTabChange} 
                    user={user} 
                    onUpdateUser={setUser}
                    onLogout={handleLogout}
                    onEditProfile={handleStartEditProfile}
                    onManageStudents={() => setIsManagingStudents(true)}
                    onContactMaster={() => setIsContactingMaster(true)}
                    onOpenMessenger={() => setIsMessagingClan(true)}
                    onDeleteMessage={deleteMessage}
                    isLider={isMestre}
                    theme={theme} setTheme={setTheme}
                    audioSettings={audioSettings} 
                    setAudioSettings={setAudioSettings}
                    sageAvatar={sageAvatar}
                    customIcons={customIcons}
                    onUpdateIcon={handleUpdateIcon}
                    onResetIcon={handleResetIcon}
                    onOpenSchedule={() => handleOpenScheduleForStudent()}
                    onOpenMasterTracking={() => setIsMasterTrackingOpen(true)}
                    onOpenQuestionnaire={() => setIsQuestionnaireOpen(true)} // Passa a função para abrir o questionário
                    // Props de Configuração de Som
                    soundConfig={soundConfig}
                    onUpdateSoundConfig={handleUpdateSoundConfig}
                >
                    {renderContent()}
                </Layout>
                
                {/* Modais Globais */}
                {isManagingStudents && (
                    <StudentManager 
                    onClose={() => setIsManagingStudents(false)} 
                    students={clanMembers}
                    onUpdateStudent={handleUpdateStudentFromManager} 
                    onDeleteStudent={handleDeleteStudent}
                    theme={theme} 
                    onOpenSchedule={handleOpenScheduleForStudent} 
                    />
                )}

                {isScheduleOpen && (
                    <InstructorSchedule 
                        onClose={() => setIsScheduleOpen(false)}
                        user={user}
                        onUpdateUser={setUser}
                        students={clanMembers}
                        theme={theme}
                        initialStudentId={scheduleTargetStudentId} 
                    />
                )}

                {/* NOVO: MODAL DE TRACKING MASTER */}
                {isMasterTrackingOpen && (
                    <MasterTrackingLog 
                        onClose={() => setIsMasterTrackingOpen(false)}
                        students={clanMembers}
                        theme={theme}
                    />
                )}

                {/* NOVO: MODAL DE QUESTIONÁRIO */}
                {isQuestionnaireOpen && (
                    <QuestionnaireModal 
                        onClose={() => setIsQuestionnaireOpen(false)}
                        onSave={handleSaveQuestionnaire}
                        theme={theme}
                    />
                )}
                
                {/* ... Modais de Falar com Mestre e Mensagens (mantidos) ... */}
                {isContactingMaster && (
                    <div className="fixed inset-0 z-[110] bg-black/80 backdrop-blur-md p-6 flex items-center justify-center animate-in fade-in zoom-in-95">
                    <div className={`${theme === 'Noite' ? 'bg-[#1A1A1A]' : 'bg-white'} w-full max-w-md p-8 rounded-[3rem] shadow-2xl border ${theme === 'Noite' ? 'border-white/5' : 'border-zinc-200'}`}>
                        <div className="flex justify-between items-center mb-6">
                        <h3 className={`text-xl font-black italic uppercase ${theme === 'Dia' ? 'text-zinc-900' : 'text-white'}`}>Falar com o Mestre</h3>
                        <button onClick={() => setIsContactingMaster(false)} className="text-zinc-500 hover:text-red-900 transition-colors"><X size={24} /></button>
                        </div>
                        <textarea 
                        value={masterMessage} onChange={e => setMasterMessage(e.target.value)}
                        placeholder="Escreva sua dúvida ou relato para o Mestre..."
                        className={`w-full h-40 ${theme === 'Noite' ? 'bg-black/40 border-white/5' : 'bg-slate-50 border-zinc-200'} border rounded-3xl p-5 text-sm font-bold focus:outline-none focus:border-red-900 transition-all resize-none`}
                        />
                        <button 
                        onClick={handleSendMessageToMaster}
                        className="w-full mt-6 bg-red-900 text-white font-black py-4 rounded-3xl shadow-xl flex items-center justify-center gap-2 italic uppercase active:scale-95 transition-all"
                        >
                        <Send size={18} /> Enviar ao Dojo
                        </button>
                    </div>
                    </div>
                )}

                {/* Modal Mensagens para o Clã */}
                {isMessagingClan && (
                    <div className="fixed inset-0 z-[110] bg-black/80 backdrop-blur-md p-6 flex items-center justify-center animate-in fade-in zoom-in-95 overflow-y-auto">
                    <div className={`${theme === 'Noite' ? 'bg-[#1A1A1A]' : 'bg-white'} w-full max-w-lg p-8 rounded-[3rem] shadow-2xl border ${theme === 'Noite' ? 'border-red-900/20' : 'border-zinc-200'}`}>
                        <div className="flex justify-between items-center mb-6">
                        <div className="flex items-center gap-3">
                            <Users size={24} className="text-red-900" />
                            <h3 className={`text-xl font-black italic uppercase ${theme === 'Dia' ? 'text-zinc-900' : 'text-white'}`}>Comando do Clã</h3>
                        </div>
                        <button onClick={() => setIsMessagingClan(false)} className="text-zinc-500 hover:text-red-900 transition-colors"><X size={24} /></button>
                        </div>

                        <div className="space-y-4">
                        <div className="space-y-1">
                            <label className="text-[10px] font-black uppercase text-zinc-500 italic ml-1">Assunto do Pergaminho</label>
                            <input 
                            value={broadcastTitle} onChange={e => setBroadcastTitle(e.target.value)}
                            placeholder="Ex: Treino de Sábado / Novo Protocolo"
                            className={`w-full p-4 rounded-2xl border ${theme === 'Noite' ? 'bg-black/40 border-white/5' : 'bg-slate-50 border-zinc-200'} text-sm font-bold focus:outline-none focus:border-red-900 transition-all`}
                            />
                        </div>
                        
                        <div className="space-y-1">
                            <label className="text-[10px] font-black uppercase text-zinc-500 italic ml-1">Conteúdo da Mensagem</label>
                            <textarea 
                            value={broadcastContent} onChange={e => setBroadcastContent(e.target.value)}
                            placeholder="Escreva a ordem para os membros..."
                            className={`w-full h-32 p-4 rounded-2xl border ${theme === 'Noite' ? 'bg-black/40 border-white/5' : 'bg-slate-50 border-zinc-200'} text-sm font-bold focus:outline-none focus:border-red-900 transition-all resize-none`}
                            />
                        </div>

                        <div className="space-y-2">
                            <div className="flex justify-between items-end">
                            <label className="text-[10px] font-black uppercase text-zinc-500 italic ml-1">Selecionar Membros</label>
                            <button onClick={toggleAllRecipients} className="text-[9px] font-black uppercase text-red-900 hover:underline">
                                {selectedRecipients.length === clanMembers.length ? 'Desmarcar Todos' : 'Selecionar Todos'}
                            </button>
                            </div>
                            
                            <div className={`max-h-40 overflow-y-auto p-2 rounded-2xl border ${theme === 'Noite' ? 'bg-black/20 border-white/5' : 'bg-slate-50 border-zinc-200'} custom-scrollbar`}>
                            {clanMembers.map(member => (
                                <button 
                                key={member.id}
                                onClick={() => toggleRecipient(member.id)}
                                className={`w-full flex items-center justify-between p-3 rounded-xl mb-1 transition-all ${selectedRecipients.includes(member.id) ? 'bg-red-900/10' : 'hover:bg-white/5'}`}
                                >
                                <div className="flex items-center gap-3">
                                    <div className="w-8 h-8 bg-zinc-800 rounded-full flex items-center justify-center text-xs text-white">{member.name.charAt(0)}</div>
                                    <span className={`text-xs font-bold uppercase ${theme === 'Dia' ? 'text-zinc-800' : 'text-zinc-300'}`}>{member.name}</span>
                                </div>
                                {selectedRecipients.includes(member.id) ? <CheckSquare size={16} className="text-red-900" /> : <Square size={16} className="text-zinc-500" />}
                                </button>
                            ))}
                            </div>
                        </div>

                        <button 
                            onClick={handleBroadcastMessage}
                            className="w-full mt-4 bg-red-900 text-white font-black py-4 rounded-3xl shadow-xl flex items-center justify-center gap-2 italic uppercase active:scale-95 transition-all"
                        >
                            <Send size={18} /> Disparar Ordem
                        </button>
                        </div>
                    </div>
                    </div>
                )}
            </>
          )}
        </>
      ) : (
        <Login 
          onLogin={handleLogin} 
          theme={theme} 
          customLogo={customIcons['loginLogo']} // Passando o ícone personalizado
        />
      )}
    </div>
  );
};

export default App;
